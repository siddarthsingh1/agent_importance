envs=(lbforaging:Foraging-15x15-4p-3f-v2 
lbforaging:Foraging-2s-8x8-2p-2f-coop-v2  
lbforaging:Foraging-2s-10x10-3p-3f-v2 
lbforaging:Foraging-8x8-2p-2f-coop-v2 
lbforaging:Foraging-15x15-4p-5f-v2
lbforaging:Foraging-15x15-3p-5f-v2
lbforaging:Foraging-10x10-3p-3f-v2)

for e in "${envs[@]}"
do
   for i in {0..1}
   do
      python src/main.py --config=$1 --env-config=gymma with env_args.key=$e seed=$i exp_main_name=$2 &&
      sleep 4s
   done
done