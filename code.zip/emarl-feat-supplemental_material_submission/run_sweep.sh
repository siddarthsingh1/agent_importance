lbf_algos=(qmix_lbf mappo_lbf maa2c_lbf iql_lbf vdn_lbf)
rware_algos=(qmix_rware mappo_rware maa2c_rware iql_rware vdn_rware)

for a in "${lbf_algos[@]}"
do
   bash run_algo_lbf.sh $a $1
done

for a in "${rware_algos[@]}"
do
   bash run_algo_rware.sh $a $1
done