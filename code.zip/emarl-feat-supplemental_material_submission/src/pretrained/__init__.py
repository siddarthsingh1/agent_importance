from .tag import PretrainedTag, RandomTag, FrozenTag
from .adversary import PretrainedAdversary