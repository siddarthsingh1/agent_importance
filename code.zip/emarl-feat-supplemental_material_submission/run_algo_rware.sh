envs=(rware:rware-tiny-2ag-v1 rware:rware-tiny-4ag-v1 rware:rware-small-4ag-v1)

for e in "${envs[@]}"
do
   for i in {0..1}
   do
      python src/main.py --config=$1 --env-config=gymma with env_args.key=$e seed=$i exp_main_name=$2 &&
      sleep 4s
   done
done