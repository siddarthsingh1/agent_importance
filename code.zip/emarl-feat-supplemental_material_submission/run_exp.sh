python src/main.py --config=vdn_lbf --env-config=gymma with env_args.key=lbforaging:Foraging-15x15-4p-3f-v2 test_nepisode=32 seed=9 exp_main_name=test_exp neptune_tag=test_exp
